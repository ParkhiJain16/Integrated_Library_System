#ifndef INDEXS_H
#define INDEXS_H

#define MIN_SIZE QSize(900,650)

#define START_WIDGET 0
#define SIGNUP_WIDGET 1
#define LOGIN_WIDGET 2
#define PUBLISHER_WIDGET 3
#define STUDENT_WIDGET 4


#endif // INDEXS_H
