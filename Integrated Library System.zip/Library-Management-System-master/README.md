## Table of contents
* [Introduction](#general-info)
* [Technologies](#technologies)
* [Prerequisites](#Prerequisites)
* [Setup](#setup)
* [Deployment](#Deployment)

## Introduction
The Library-Management-System is a software system with a Graphical User Interface to provide the libraries with a helpfull software system that has features like: registration system, publishing books system, borrowing system and searching and payment methods.

## Technologies
Project is created with:
*	C++
*	QT Framework
*	CSS3
*	SQLite

## User Guide
Check the User Guide located in "Doucmentation/user_guide.pdf"

